distanceOffset={};
distanceOffset.loc=0;
function addDrag(dragCount){
for(i=1;i<=dragCount;i++){
dragElement(document.getElementById("drag"+i));
}
}
function drawAllLines(list){
	for(i=0;i<list.length;i++){
		var a=parseInt(list[i].charAt(0));
		var b=parseInt(list[i].charAt(1));
		drawLine(a,b);
	}
}
function getCenterX(div1){
	var offset = div1.offset();
var width = div1.width();
var height = div1.height();

var centerX = offset.left + width / 2;
var centerY = offset.top + height / 2;
return centerX;
}
function getCenterY(div1){
var offset = div1.offset();
var width = div1.width();
var height = div1.height();

var centerX = offset.left + width / 2;
var centerY = offset.top + height / 2;
return centerY;
}


function drawCondition(l,texttoadd){
	var x=parseInt(l.charAt(0))-1;
	var div1=$('#c'+x);
	console.log('ff'+texttoadd+l.charAt(0)+''+l.charAt(0));
	var centerX=getCenterX(div1);
	var centerY=parseInt(distanceOffset.loc)+200;
	distanceOffset.loc+=200;
	var z=$('#cond'+l);
	if(z.length==0){
		$('.cond').append('<div id="cond'+l+'" class="element condition">'+texttoadd+'</div>');
	}
	$('#cond'+l).css('top',centerY+'px');
	$('#cond'+l).css('left',centerX+'px');
}
function drawText(i,j,id,texttoadd){
	var div1=$("#a"+id);
	var txt=$('#at'+id);
	txt.text(texttoadd);
	centerX1=getCenterX(div1);
	centerY1=getCenterY(div1);
	var mXY=(getMXY(div1.attr('d'))).split(',');//Has MoveTo of line so it can be directly used
	var mX=parseInt(mXY[0].substr(2));
	var mY=mXY[1];
	if(parseInt(i)>parseInt(j)){
	mX-=200;
	txt.attr('x',mX);
	}
	else{
		txt.attr('x',mX+5);
	}
	if(!distanceOffset.loc){
		txt.attr('y',mY-5);
	}
	else{
	txt.attr('y',distanceOffset.loc-2);
	}
	distanceOffset.loc+=30;
}
function drawReverseText(i,j,id,texttoadd){
	var div1=$("#ar"+id);
	var txt=$('#rat'+id);
	txt.text(texttoadd);
	centerX1=getCenterX(div1);
	centerY1=getCenterY(div1);
	var mXY=(getMXY(div1.attr('d'))).split(',');//Has MoveTo of line so it can be directly used
	var mX=parseInt(mXY[0].substr(2));
	var mY=mXY[1];
	txt.attr('x',mX+2);
	txt.attr('y',mY-3);
	distanceOffset.loc+=20;
}
function drawReversedArrow(i,j,id){
	var div1=$("#c"+i);
	var revLine=$('#ar'+id);
	if(revLine.length==0){
		var newLine = document.createElementNS('http://www.w3.org/2000/svg','path');
		newLine.setAttribute('id','ar'+id);
		newLine.setAttribute('marker-end','url(#head)');
		newLine.setAttribute( 'stroke-width','1.5');
		newLine.setAttribute('fill','none');
		newLine.setAttribute('stroke','red');
		$('svg').append(newLine);
		
		newLine = document.createElementNS('http://www.w3.org/2000/svg','text');
		newLine.setAttribute('id','rat'+id);
		$('svg').append(newLine);
	}
	revLine=$('#ar'+id);
	centerX1=getCenterX(div1)+5;
	centerY1=(distanceOffset.loc+20);
	distanceOffset.loc=centerY1+50;
	revLine.attr('d','M '+(centerX1)+','+(centerY1)+' L '+(centerX1+50)+','+(centerY1)+'L'+(centerX1+50)+','+(centerY1+50)+' L'+(centerX1)+','+(centerY1+50));
}
function getMXY(a){
	var counter=0;
	var s='';
	for(i=0;i<a.length;i++){
		if(a.charAt(i)===' '){
			if(counter===1)return s;
			else{
				counter++;
				s+=a.charAt(i);
			}
		}
		else{
			s+=a.charAt(i);
		}
	}
}
function drawCurve(i,j,id){
	var div1=$("#c"+i+''+i);
	var div2=$("#c"+j+''+j);
	var arrowedLine=$('#a'+id);
	if(arrowedLine.length==0){
		var newLine = document.createElementNS('http://www.w3.org/2000/svg','path');
		newLine.setAttribute('id','a'+id);
		newLine.setAttribute('marker-end','url(#head)');
		newLine.setAttribute( 'stroke-width','1.5');
		newLine.setAttribute('fill','none');
		newLine.setAttribute('stroke','red');
		$('svg').append(newLine);
		
		newLine = document.createElementNS('http://www.w3.org/2000/svg','text');
		newLine.setAttribute('id','at'+id);
		$('svg').append(newLine);
	}
	arrowedLine=$('#a'+id);
	centerX1=getCenterX(div1);
	centerX2=getCenterX(div2);
	if(distanceOffset.loc==0){
	centerY1=getCenterY(div1);
	centerY2=getCenterY(div2);	
	}
	else{
	centerY1=distanceOffset.loc-10;
	centerY2=centerY1;
	}
	arrowedLine.attr('d','m '+(centerX1-10)+','+(centerY1+20)+' L '+(centerX2-4)+','+(centerY2+20));
	distanceOffset.loc=centerY1+20;
}
function drawLine(i,j){
line1 = $('#c'+i+''+j);
div1 = $('#c'+i);

var centerX = getCenterX(div1);
var centerY = getCenterY(div1);

line1
  .attr('x1', centerX)
  .attr('y1', centerY-50)
  .attr('x2', centerX)
  .attr('y2', centerY+1500);

}
function dragElement(elmnt) {
  var pos1 = 0, pos2 = 0, pos3 = 0, pos4 = 0;
  if (document.getElementById(elmnt.id + "header")) {
    /* if present, the header is where you move the DIV from:*/
    document.getElementById(elmnt.id + "header").onmousedown = dragMouseDown;
  } else {
    /* otherwise, move the DIV from anywhere inside the DIV:*/
    elmnt.onmousedown = dragMouseDown;
  }
}

  function dragMouseDown(e) {
    e = e || window.event;
    // get the mouse cursor position at startup:
    pos3 = e.clientX;
    pos4 = e.clientY;
    document.onmouseup = closeDragElement;
    // call a function whenever the cursor moves:
    document.onmousemove = elementDrag;
  }

  function elementDrag(e) {
    e = e || window.event;
    // calculate the new cursor position:
    pos1 = pos3 - e.clientX;
    pos2 = pos4 - e.clientY;
    pos3 = e.clientX;
    pos4 = e.clientY;
    // set the element's new position:
    elmnt.style.top = (elmnt.offsetTop - pos2) + "px";
    elmnt.style.left = (elmnt.offsetLeft - pos1) + "px";
	drawAllLines();
  }

  function closeDragElement() {
    /* stop moving when mouse button is released:*/
    document.onmouseup = null;
    document.onmousemove = null;
}