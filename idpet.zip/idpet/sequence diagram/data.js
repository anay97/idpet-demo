dt1={
	"name":"Door1",
	"elements":[':User','Controller','Passcode','Door'],
	"order":['121','221','21','211','122','222','231','321','22','241','421','212','23','242','422','213'],
	"lines":{		
		"121":{
			"type":"normal",
			"text":"1. User selects option lock",
			"from":"1",
			"to":"2"
		},
		"221":{
			"type":"reversed",
			"text":"2: setOption:(option:String) : String",
			"from":"2"
		},
		"21":{
			"type":"condition",
			"on":"2",
			"text":'{if(optionSelected=="lock")}'
		},
		"211":{
			"type":"normal",
			"text":"3: MSG:Enter Passcode",
			"from":"2",
			"to":"1"
		},
		"122":{
			"type":"normal",
			"text":"4: Event:Enter Passcode",
			"from":"1",
			"to":"2"
		},
		"222":{
			"type":"reversed",
			"text":"5: inputPasscode(): String",
			"from":"2"
		},
		"231":{
			"type":"normal",
			"text":"6: checkPasscode(input:String):bool",
			"from":"2",
			"to":"3"
		},
		"321":{
			"type":"normal",
			"text":"7: return result",
			"from":"3",
			"to":"2"
		},
		"22":{
			"type":"condition",
			"on":"2",
			"text":'{if(result==true)}'
		},
		"241":{
			"type":"normal",
			"text":"8: lock():bool",
			"from":"2",
			"to":"4"
		},
		"421":{
			"type":"normal",
			"text":"9: return true",
			"from":"4",
			"to":"2"
		},
		"212":{
			"type":"normal",
			"text":"10: MSG: Door Locked",
			"from":"2",
			"to":"1"
		},
		"23":{
			"type":"condition",
			"on":"2",
			"text":'{if(result==false)}'
		},
		"242":{
			"type":"normal",
			"text":"11: unlock():bool",
			"from":"2",
			"to":"4"
		},
		"422":{
			"type":"normal",
			"text":"12: return true",
			"from":"4",
			"to":"2"
		},
		"213":{
			"type":"normal",
			"text":"13: MSG: Incorrect Passcode",
			"from":"2",
			"to":"1"
		},
		
		
	}
};
dt2={
	"name":"Door2",
	"elements":[':aUser','Controller','Passcode','Door'],
	"order":['121','221','21','211','122','222','231','321','22','241','421','212','23','242','422','213'],
	"lines":{		
		"121":{
			"type":"normal",
			"text":"1. User selects option lock",
			"from":"1",
			"to":"2"
		},
		"221":{
			"type":"reversed",
			"text":"2: setOption:(option:String) : String",
			"from":"2"
		},
		"21":{
			"type":"condition",
			"on":"2",
			"text":'{if(optionSelected=="lock")}'
		},
		"211":{
			"type":"normal",
			"text":"3: MSG:Enter Passcode",
			"from":"2",
			"to":"1"
		},
		"122":{
			"type":"normal",
			"text":"4: Event:Enter Passcode",
			"from":"1",
			"to":"2"
		},
		"222":{
			"type":"reversed",
			"text":"5: inputPasscode(): String",
			"from":"2"
		},
		"231":{
			"type":"normal",
			"text":"6: checkPasscode(input:String):bool",
			"from":"2",
			"to":"3"
		},
		"321":{
			"type":"normal",
			"text":"7: return result",
			"from":"3",
			"to":"2"
		},
		"22":{
			"type":"condition",
			"on":"2",
			"text":'{if(result==true)}'
		},
		"241":{
			"type":"normal",
			"text":"8: lock():bool",
			"from":"2",
			"to":"4"
		},
		"421":{
			"type":"normal",
			"text":"9: return true",
			"from":"4",
			"to":"2"
		},
		"212":{
			"type":"normal",
			"text":"10: MSG: Door Locked",
			"from":"2",
			"to":"1"
		},
		"23":{
			"type":"condition",
			"on":"2",
			"text":'{if(result==false)}'
		},
		"242":{
			"type":"normal",
			"text":"11: unlock():bool",
			"from":"2",
			"to":"4"
		},
		"422":{
			"type":"normal",
			"text":"12: return true",
			"from":"4",
			"to":"2"
		},
		"213":{
			"type":"normal",
			"text":"13: MSG: Incorrect Passcode",
			"from":"2",
			"to":"1"
		},
		
		
	}
}