$(document).ready(function(){
addTabs();
refresher(dt1);
$('.tab').click(function(){
	var id=$(this)[0].id;
	$('#tabs').children().each(function(){
		$(this).removeClass('active');
	})
	$(this).addClass('active');
	var dataset=window[''+id];
	refresher(dataset);
})
})
function addTabs(){
	for(i=1;i<=10;i++){
		var x=window['dt'+i];
		if(x==undefined){
			break;
		}
		if(i==1){			
		$('#tabs').append('<div id="dt'+i+'" class="tab active">'+window['dt'+i].name+'</div>');
		}
		else{		
		$('#tabs').append('<div id="dt'+i+'" class="tab">'+window['dt'+i].name+'</div>');
		}
	}
}
function refresher(dataset){
$('.c').text('');
$('svg').text('');
$('.cond').text('');
distanceOffset.loc=0;
var dt=dataset;
var elems=dt.elements;
var list=[];
for(var i=0;i<elems.length;i++){
	var x=i+1;
	list.push(x+''+x);
	$('.c').append('<div id="c'+(i+1)+'" class="element">'+elems[i]+'</div>');
	var newLine = document.createElementNS('http://www.w3.org/2000/svg','line');
		newLine.setAttribute('id','c'+x+''+x);
		newLine.setAttribute('stroke','red');
		newLine.setAttribute('stroke-width','1.5');
		newLine.setAttribute('stroke-dasharray','5,5');
		newLine.setAttribute('d','M5 20 l215 0');
		$('svg').append(newLine);
}

drawAllLines(list);

var x=1;
var keys=dt.order;
for(var i=0;i<keys.length;i++){	
	var key=''+keys[i];
	var x=keys[i]+'';
	var val=dt.lines[x];

	if(val.type=="normal"){
			console.log(x++ +val.text);
			drawCurve(val.from,val.to,key);
			drawText(val.from,val.to,key,val.text);
		}
		else if(val.type=="reversed"){
			console.log(x++ +val.text);
			drawReversedArrow(val.from,val.from,key);
			drawReverseText(val.from,val.from,key,val.text);
		}
		else if(val.type=="condition"){
			drawCondition(key,val.text);
			console.log(x++ +val.text);
		}
}
}