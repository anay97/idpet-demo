1. to open-->

go to attempt2

click on index.html


for any json file, go to the folder for the diagram and then click on data.js