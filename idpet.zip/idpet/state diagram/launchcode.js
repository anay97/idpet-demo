$(document).ready(function(){

addDrag(1);
})
$(document).on('click','.addButton',function(){
	var clickedButtonId=($(this)[0].id);
	newState(clickedButtonId);
})
$(document).on('click','.draggableheader',function(evt){
	if (evt.ctrlKey)
		getNewText($(this).parent()[0].id);

})
$(document).on('click','textPath',function(evt){
	if (evt.ctrlKey)
		getNewTextPath($(this).parent()[0].id);
})
