$(document).ready(function(){

addDrag(1);
})
$(document).on('click','.addButton',function(){
	var clickedButtonId=($(this)[0].id);
	newState(clickedButtonId);
})
$(document).on('contextmenu','.draggableheader',function(evt){
	getNewText($(this).parent()[0].id);
	evt.preventDefault();

})
$(document).on('click','textPath',function(evt){
	if (evt.ctrlKey)
		getNewTextPath($(this).parent()[0].id);
})
$(document).on('click',function(){
	var body = document.body;
	var width= Math.max( body.scrollWidth, body.offsetWidth);
	$('#statesvg').attr('width',width+'px');
})
