stateNum={};
stateNum.count=1;
map={};
function newState(clickedButtonId){
	stateNum.count++;
	document.getElementById("container").innerHTML+='<div id="s'+stateNum.count+'" class="draggable state"><div id="s'+stateNum.count+'header" class="draggableheader">New State</div><div id="s'+stateNum.count+'button" class="addButton">+</div>';
	addDrag(stateNum.count);
	cX=getCenterX($('#'+clickedButtonId).parent());
	cY=getCenterY($('#'+clickedButtonId).parent());
	$('#s'+stateNum.count).css('top',cY);
	$('#s'+stateNum.count).css('left',cX+100);
	var fromId=$('#'+clickedButtonId).parent();
	map[''+stateNum.count]=fromId[0].id;
	drawLine(fromId[0].id,'s'+stateNum.count);
}
function getNewText(stateId){
	var txt='';
	$('#'+stateId+'>.draggableheader').text('');
	
	$(document).keydown(function(e){
		var keyC=e.which;
		//Handle backspace here
		if(keyC==8){
		var x=$('#'+stateId+'>.draggableheader').text();
		x=x.substr(0,x.length-1);
		$('#'+stateId+'>.draggableheader').text(x);
		}
	});
	
	$(document).keypress(function (e) {
	var keyC = e.which;
	if(keyC==13){
		$(document).off('keypress');
		$(document).off('keydown');
	}
	//Backspace is handled from keydown
	//Space
	if(keyC==32){
		$('#'+stateId+'>.draggableheader').append(" ");
		e.preventDefault();
	}	
	//Opening bracket
	if(keyC==40){
		$('#'+stateId+'>.draggableheader').append("(");
	}
	//Closing bracket
	if(keyC==41){
		$('#'+stateId+'>.draggableheader').append(")");
	}
	if ((e.which < 65 || e.which > 122) && (e.which < 48 || e.which > 57)){
        e.preventDefault();
    }
	else{
	var key=String.fromCharCode(keyC);
	$('#'+stateId+'>.draggableheader').append(key);
	}
	});
}
function getNewTextPath(stateId){
	var txt='';
	$('#'+stateId+' > textPath').text('');
	
	$(document).keydown(function(e){
		var keyC=e.which;
		//Handle backspace here
		if(keyC==8){
		var x=$('#'+stateId+'>textPath').text();
		x=x.substr(0,x.length-1);
		$('#'+stateId+'>textPath').text(x);
		}
	});
	
	$(document).keypress(function (e) {
	var keyC = e.which;
	if(keyC==13){
		$(document).off('keypress');
		$(document).off('keydown');
	}
	//Backspace is handled from keydown
	//Space
	if(keyC==32){
		$('#'+stateId+' > textPath').append(" ");
		e.preventDefault();
	}	
	//Opening bracket
	if(keyC==40){
		$('#'+stateId+' > textPath').append("(");
	}
	//Closing bracket
	if(keyC==41){
		$('#'+stateId+' > textPath').append(")");
	}
	if ((e.which < 65 || e.which > 122) && (e.which < 48 || e.which > 57)){
        e.preventDefault();
    }
	else{
	var key=String.fromCharCode(keyC);
	$('#'+stateId+' > textPath').append(key);
	}
	});
}
function drawLine(clickedButtonId,newId){
	var div1=$("#"+clickedButtonId);
	var div2=$("#"+newId);
	var id=clickedButtonId+'To'+newId;
	if($('#'+id).length==0){
		document.getElementById('statesvg').innerHTML+="<path class='line' id='"+id+"' marker-end='url(#head)' stroke-width='1.5' fill='none' stroke='red'/>";
	}
	var arrowedLine=$('#'+id);
	centerX1=getCenterX(div1);
	centerX2=getCenterX(div2);
	centerY1=getCenterY(div1);
	centerY2=getCenterY(div2);	
	arrowedLine.attr('d','m '+(centerX1)+','+(centerY1+20)+' L '+(centerX2)+','+(centerY2+20));
	drawText(id);
}
function drawText(lineId){
	var div1=$("#"+lineId);
	var txt=$('#txt'+lineId);
	if(txt.length==0){
		document.getElementById('statesvg').innerHTML+='<text id="txt'+lineId+'"><textPath href="#'+lineId+'">Text</textPath></text>';
	}
	//centerX1=getCenterX(div1);
	//centerY1=getCenterY(div1);
	var mXY=(getMXY(div1.attr('d'))).split(',');//Has MoveTo of line so it can be directly used
	var mX=parseInt(mXY[0].substr(2));
	var mY=mXY[1];	
	txt.attr('x',mX);
	txt.attr('y',mY);
}

function getMXY(a){
	var counter=0;
	var s='';
	for(i=0;i<a.length;i++){
		if(a.charAt(i)===' '){
			if(counter===1)return s;
			else{
				counter++;
				s+=a.charAt(i);
			}
		}
		else{
			s+=a.charAt(i);
		}
	}
}

function drawAllArrows(){
for (var key in map) {
  if (map.hasOwnProperty(key)) {
    var val = map[key];
    drawLine(val,'s'+key);
  }
}

}
function addDrag(dragCount){
for(i=1;i<=dragCount;i++){
dragElement(document.getElementById("s"+i));
}
}

function getCenterX(div1){
	var offset = div1.offset();
var width = div1.width();
var height = div1.height();

var centerX = offset.left + width / 2;
var centerY = offset.top + height / 2;
return centerX;
}
function getCenterY(div1){
var offset = div1.offset();
var width = div1.width();
var height = div1.height();

var centerX = offset.left + width / 2;
var centerY = offset.top + height / 2;
return centerY;
}
function dragElement(elmnt) {
  var pos1 = 0, pos2 = 0, pos3 = 0, pos4 = 0;
  if (document.getElementById(elmnt.id + "header")) {
    /* if present, the header is where you move the DIV from:*/
    document.getElementById(elmnt.id + "header").onmousedown = dragMouseDown;
  } else {
    /* otherwise, move the DIV from anywhere inside the DIV:*/
    elmnt.onmousedown = dragMouseDown;
  }

  function dragMouseDown(e) {
    e = e || window.event;
    // get the mouse cursor position at startup:
    pos3 = e.clientX;
    pos4 = e.clientY;
    document.onmouseup = closeDragElement;
    // call a function whenever the cursor moves:
    document.onmousemove = elementDrag;
  }

  function elementDrag(e) {
    e = e || window.event;
    // calculate the new cursor position:
    pos1 = pos3 - e.clientX;
    pos2 = pos4 - e.clientY;
    pos3 = e.clientX;
    pos4 = e.clientY;
    // set the element's new position:
    elmnt.style.top = (elmnt.offsetTop - pos2) + "px";
    elmnt.style.left = (elmnt.offsetLeft - pos1) + "px";
	drawAllArrows();
  }

  function closeDragElement() {
    /* stop moving when mouse button is released:*/
    document.onmouseup = null;
    document.onmousemove = null;
  }
}