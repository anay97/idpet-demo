function addNewClass(cname,dm,mf,count){
	$('#cs').append('<div id="drag'+count+'" class="draggable"><div id="drag'+count+'header" class="draggableheader"><b>'+cname+'</b></div><div class="data-members">'+dm+'</div>'+mf+'</div>');
}
function addLines(list){
	for(var i=0;i<list.length;i++){
		var newLine = document.createElementNS('http://www.w3.org/2000/svg','line');
		newLine.setAttribute('id','c'+list[i]);
		newLine.setAttribute('x1','0');
		newLine.setAttribute('y1','0');
		newLine.setAttribute('x2','300');
		newLine.setAttribute('y2','300');
		newLine.setAttribute('stroke','black');
		$('svg').append(newLine);
	}
}
function addDrag(dragCount){
for(i=1;i<=dragCount;i++){
dragElement(document.getElementById("drag"+i));
}
}
function drawAllLines(list){
	for(i=0;i<list.length;i++){
		var a=parseInt(list[i].charAt(0));
		var b=parseInt(list[i].charAt(1));
		drawLine(a,b);
	}
}
function drawLine(i,j){
var line1 = $('#c'+i+''+j);

div1 = $('#drag'+i);   
div2 = $('#drag'+j);
var pos1 = div1.position();
var pos2 = div2.position();
line1
  .attr('x1', pos1.left)
  .attr('y1', pos1.top)
  .attr('x2', pos2.left)
  .attr('y2', pos2.top);

}
function dragElement(elmnt) {
  var pos1 = 0, pos2 = 0, pos3 = 0, pos4 = 0;
  if (document.getElementById(elmnt.id + "header")) {
    /* if present, the header is where you move the DIV from:*/
    document.getElementById(elmnt.id + "header").onmousedown = dragMouseDown;
  } else {
    /* otherwise, move the DIV from anywhere inside the DIV:*/
    elmnt.onmousedown = dragMouseDown;
  }

  function dragMouseDown(e) {
    e = e || window.event;
    // get the mouse cursor position at startup:
    pos3 = e.clientX;
    pos4 = e.clientY;
    document.onmouseup = closeDragElement;
    // call a function whenever the cursor moves:
    document.onmousemove = elementDrag;
  }

  function elementDrag(e) {
    e = e || window.event;
    // calculate the new cursor position:
    pos1 = pos3 - e.clientX;
    pos2 = pos4 - e.clientY;
    pos3 = e.clientX;
    pos4 = e.clientY;
    // set the element's new position:
    elmnt.style.top = (elmnt.offsetTop - pos2) + "px";
    elmnt.style.left = (elmnt.offsetLeft - pos1) + "px";
	drawAllLines(list);
  }

  function closeDragElement() {
    /* stop moving when mouse button is released:*/
    document.onmouseup = null;
    document.onmousemove = null;
  }
}