$(document).ready(function(){
	var i=1;
	var classes=dt.classes;
	for (var key in classes) {
	  if (classes.hasOwnProperty(key)) {
		var val = classes[key];
		addNewClass(key,val.datamembers,val.memberfunctions,i++);
	  }
	}
	list=[];
	var links=dt.links;
	for (var key in links) {
	  if (links.hasOwnProperty(key)) {
		var val = links[key];
		list.push(val);
		}
	}	
	
	var dragCount=Object.keys(dt.classes).length;
	addDrag(dragCount);
	orderElements(dragCount);
	addLines(list);
	drawAllLines(list);


} )
